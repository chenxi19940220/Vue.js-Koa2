<?php
exit(file_get_contents('data.json'));